<script setup>
import TitleBar from '@/components/TitleBar.vue';
</script>

<template>
  <div>
    <TitleBar tag="About Us">ABOUT OUR ORGANIZATION</TitleBar>
    <div>
      <p class="green fw-bold text-center mt-5 mb-2">About Us</p>
      <p class="fw-bold text-center">Sehed Society</p>
      <div class="content px-4">
        <p>
          Almost 20 years ago, from Sehed, a village in Pirojpur, began his first steps as an MFI. We are committed to

          eradicating poverty and improving the quality of life by providing the right financial services to all.
        </p>
        <p>
          Sehed is an MFI with roots in Bangladesh and we believe that through efficient and convenient high-tech

          digital, Means we can provide all people with the financial services they need and match, thus solving the

          various challenges they facing in their lifes.
        </p>
        <p>
          Sehed is registered with regulatory authorities of Government of Bangladesh, Microcredit Regulatory Authority,
          commonly known as MRA which is under the management of Bangladesh Bank.
        </p>
        <p>
          Sehed has a mission to provide a better life with dignity in the family and society through their capacity
          building, adaptability, responsiveness, optimum use of their own/available resources, participation in
          development
          activities, good governance, and establishment of their legitimate rights on a sustainable footing.
        </p>
      </div>
    </div>
  </div>
</template>
<style>
.content {
  color: rgba(152, 147, 141, 1);
  max-width: 1200px;
  display: block;
  margin: 20px auto;
}

.content p {
  padding-bottom: 20px;
  font-size: 18px;
}
</style>
