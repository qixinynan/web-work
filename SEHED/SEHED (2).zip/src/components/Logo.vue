<template>
  <div class="logo">
    <span class="logo-big">Sehed</span>
    <span class="logo-slogen">Development & Inclusive</span>
  </div>
</template>
<style scoped>
.logo {
  display: flex;
  flex-direction: column;
  color: rgba(9, 173, 9, 1);
}

.logo-big {
  font-weight: 600;
  font-size: 50px;
  color: rgba(9, 173, 9, 1);
}

.logo-slogen {
  margin-top: -12px;
}
</style>