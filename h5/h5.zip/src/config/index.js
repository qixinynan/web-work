export default {
  downloadUrl: 'mate://mate.web.app'
} 