<template>
  <div class="panel">

  </div>
</template>
<style>
.panel {
  background-color: red;
  height: 70px;
  width: 100%;
  position: absolute;
  bottom: 0px;
}
</style>